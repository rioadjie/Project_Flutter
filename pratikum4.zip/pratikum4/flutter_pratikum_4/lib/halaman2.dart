import 'package:flutter/material.dart';

class Halaman2 extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Testing Column Widget"),
      ),
      body: Column(
        children: const [
          Text("Teks Satuu"),
          Text("Teks Duaa"),
          Text("Teks Tigaa")
        ],
      ),
    );
  }
}
