import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ProdukForm extends StatefulWidget {
  const ProdukForm({Key? keys}) : super(key: keys);

  _ProdukFormState createState() => _ProdukFormState();
}

class _ProdukFormState extends State<ProdukForm> {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Form Produk"),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          _textboxKodeProduk(),
          _textboxNamaProduk(),
          _textboxHargaSatuan(),
          _textboxTombolSimpan()
        ]),
      ),
    );
  }
}

_textboxKodeProduk() {
  return TextField(
    decoration: const InputDecoration(labelText: "Kode Produk"),
  );
}

_textboxNamaProduk() {
  return TextField(
    decoration: const InputDecoration(labelText: "Nama Produk"),
  );
}

_textboxHargaSatuan() {
  return TextField(
    decoration: const InputDecoration(labelText: "Harga Satuan"),
  );
}

_textboxTombolSimpan() {
  return ElevatedButton(onPressed: () {}, child: const Text("Simpan"));
}
