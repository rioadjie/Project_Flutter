import 'dart:html';
import 'dart:js_util';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class BiodataForm extends StatefulWidget {
  const BiodataForm({Key? keys}) : super(key: keys);

  _BiodataFormState createState() => _BiodataFormState();
}

class _BiodataFormState extends State<BiodataForm> {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Form Input Biodata"),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          _textboxNik(),
          _textboxNama(),
          _textboxTempatLahir(),
          _textboxAlamat(),
          _textboxJurusan(),
          _textboxTombolSimpan(),
          _textboxTombolClear()
        ]),
      ),
    );
  }
}

TextEditingController nik = TextEditingController();
TextEditingController nama = TextEditingController();
TextEditingController tanggal_lahir = TextEditingController();
TextEditingController alamat = TextEditingController();
TextEditingController jurusan = TextEditingController();

_textboxNik() {
  return TextField(
    controller: nik,
    decoration: const InputDecoration(labelText: "NIK"),
    // hanya menginputkan angka
    keyboardType: TextInputType.number,
    inputFormatters: <TextInputFormatter>[
      FilteringTextInputFormatter.digitsOnly
    ],
  );
}

_textboxNama() {
  return TextField(
    controller: nama,
    decoration: const InputDecoration(labelText: "Nama Lengkap"),
  );
}

_textboxTempatLahir() {
  return TextField(
    controller: tanggal_lahir,
    decoration: const InputDecoration(labelText: "Tempat Tanggal Lahir"),
  );
}

_textboxAlamat() {
  return TextField(
    controller: alamat,
    decoration: const InputDecoration(labelText: "Alamat Lengkap"),
  );
}

_textboxJurusan() {
  return TextField(
    controller: jurusan,
    decoration: const InputDecoration(labelText: "Jurusan"),
  );
}

_textboxTombolSimpan() {
  return ElevatedButton(onPressed: () {}, child: const Text("SIMPAN"));
}

_textboxTombolClear() {
  return ElevatedButton(
      onPressed: () {
        nik.clear();
        nama.clear();
        tanggal_lahir.clear();
        alamat.clear();
        jurusan.clear();
      },
      child: const Text("CLEAR"));
}
