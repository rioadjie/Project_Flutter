import 'package:flutter/material.dart';
// import 'package:flutter_pratikum_4/hello_word.dart';
// import 'package:flutter_pratikum_4/halaman2.dart';
// import 'package:flutter_pratikum_4/halaman3.dart';
import 'package:flutter_pratikum_4/ui/produk_form.dart';
import 'package:flutter_pratikum_4/ui/biodata_form.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi Flutter Pemula - Rio Adjie Wiguna',
      home: BiodataForm(),
    );
  }
}
