import 'package:flutter/material.dart';

class HelloWorld extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Selamat Datang di Flutter Awal Guysss..."),
      ),
      body: const Center(
        child: Text("Lagi Belajar Flutter Nih Moga Berhasil.."),
      ),
    );
  }
}
