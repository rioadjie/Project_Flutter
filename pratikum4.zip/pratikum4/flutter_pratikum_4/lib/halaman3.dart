import 'package:flutter/material.dart';

class Halaman3 extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Testing Row Widget"),
      ),
      body: Row(
        children: const [
          Text("Teknik Informatika   "),
          Text("Teknik Sipil   "),
          Text("Teknik Mesin")
        ],
      ),
    );
  }
}
