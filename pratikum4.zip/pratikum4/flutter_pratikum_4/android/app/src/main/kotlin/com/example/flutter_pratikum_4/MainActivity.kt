package com.example.flutter_pratikum_4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
